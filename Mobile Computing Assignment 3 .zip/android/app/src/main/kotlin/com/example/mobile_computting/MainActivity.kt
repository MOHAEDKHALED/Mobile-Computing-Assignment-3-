package com.example.mobile_computting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
